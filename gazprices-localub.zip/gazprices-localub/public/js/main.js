(self.webpackChunk=self.webpackChunk||[]).push([[179],{656:function(){0},253:function(e,t,n){"use strict";var i=n(378),l=n(542),o=n(609),r=n(338),a=function(e,t){var n={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&t.indexOf(i)<0&&(n[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var l=0;for(i=Object.getOwnPropertySymbols(e);l<i.length;l++)t.indexOf(i[l])<0&&Object.prototype.propertyIsEnumerable.call(e,i[l])&&(n[i[l]]=e[i[l]])}return n};var c=function(e){var{size:t=35}=e,n=a(e,["size"]);return i.createElement(r.animated.svg,Object.assign({width:t,height:t,viewBox:"0 0 25 25",fill:"none"},n),i.createElement("path",{d:"M16.667 5.208v14.584L5.208 12.5l11.459-7.292z",fill:"#000"}))},s=n(465),d=function(e,t,n,i){return new(n||(n=Promise))((function(l,o){function r(e){try{c(i.next(e))}catch(e){o(e)}}function a(e){try{c(i.throw(e))}catch(e){o(e)}}function c(e){var t;e.done?l(e.value):(t=e.value,t instanceof n?t:new n((function(e){e(t)}))).then(r,a)}c((i=i.apply(e,t||[])).next())}))};const p=o.ZP.span`
width: 81px;
height: 23.02px;
cursor: pointer;
font-family: 'SF Compact';
font-style: normal;
font-weight: 556;
font-size: 12px;
line-height: 14px;
display: flex;
align-items: center;
text-align: center;
justify-content: center;
color: ${({active:e})=>e?"#099438":"#000000"};
transform: scale(1);
:active{
  transform: scale(.95);
}
transition: all ease-in-out 100ms;
/* Inside auto layout */
flex: none;
order: 0;
flex-grow: 0;
`,u=(0,o.ZP)(s.Z)`
box-sizing: border-box;
scroll-snap-points-y: repeat(81px);
scroll-snap-type: y mandatory;
scroll-snap-align: start;
scroll-behavior: smooth;
/* Auto layout */
-ms-overflow-style: none;  /* IE and Edge */
scrollbar-width: none;  /* Firefox */
display: flex;
flex-direction: row;
align-items: center;
padding: 0px 2px;
gap: 1px;
isolation: isolate;
width: 100%;
height: 34px;
overflow-x: scroll;

background: #FFFFFF;
border-bottom: 0.2px solid #999797;

/* Inside auto layout */
flex: none;
align-self: stretch;
flex-grow: 0;
`,x=o.ZP.span`
width: 25%;
height: 24px;
font-family: 'SF Compact';
font-style: normal;
font-weight: 556;
font-size: 12px;
line-height: 14px;
display: flex;
align-items: center;
text-align: center;
color: #099438;
/* Inside auto layout */
flex: none;
align-items: center;
justify-content: center;
order: 2;
flex-grow: 0;
`,f=o.ZP.hr`
width: 23.02px;
height: 0px;
margin: 0px 1px;
border: .7px solid #C2C2C2;
transform: rotate(-90deg);
/* Inside auto layout */
background-color: #C2C2C2;
flex: none;
order: 1;
flex-grow: 0;
`,g=o.ZP.span`
/* Essence */
/* width: 143px; */
width: 65%;
height: 21px;
align-items: center;
justify-content: center;
font-style: normal;
font-weight: 556;
font-size: 15px;
line-height: 18px;
display: flex;
align-items: center;
text-align: center;
color: #000000;
/* Inside auto layout */
text-align: center;
flex: none;
order: 0;
flex-grow: 0;
`,h=o.ZP.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  padding: 2px;
  gap: 0px;
  width: 92%;
  height: 34px;
  background: #FFFFFF;
  border-bottom: 0.2px solid #999797;
  /* Inside auto layout */
  flex: none;
  order: 0;
  align-self: stretch;
  flex-grow: 0;
  padding:0px 4%;
`,m=o.ZP.div`
  @import url('https://fonts.googleapis.com/css2?family=Rubik:wght@300&display=swap');
  font-family: 'Rubik', sans-serif;
  * {
  font-family: 'Rubik', sans-serif;
  user-select: none;
  }
  color: #444;
  filter: drop-shadow(3px 2px 2px rgba(0, 0, 0, 0.1));
  &:active{
    filter: drop-shadow(3px 0px 1px rgba(0, 0, 0, 0.1));
  }
  position: fixed;
  top: 20%;
  width: auto;
  left: 0px;
  display: flex;
  transition: filter ease-in-out 100ms;
  /* width: auto; */
  flex-direction: row;
  flex-wrap: nowrap;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px;
`,v=o.ZP.div`
    box-sizing: border-box;
    /* Auto layout */
    padding: 0px !important;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 0px 1px;
    width: ${({w:e})=>0===e?0:207}px;
    overflow: hidden;
    /* width: auto; */
    height: 135px;
    background: #FFFFFF;
    border-right: 0.2px solid #999797;
    border-radius: 0px 0px 8px 0px;
    /* Inside auto layout */
    transition: all ease-in-out 100ms;
    flex: none;
    order: 0;
    flex-grow: 0;
    /* transform: scaleX(${({w:e})=>e}); */
    /* max-width: 227px; */
    height: 135px;
`,y=o.ZP.button`
    max-width: 53px;
    max-height: 56px;
    min-width: 23px;
    min-height: 26px;
    width: 3.1vw;
    height: 3vw;
    background: #FFFFFF;
    border-radius: 0px 35% 35% 0px;
    outline: none;
    border: none;
    user-select: none;
    padding: 0px;
    cursor: pointer;
    * {
    user-select: none;
    }
    display: flex;
    align-items: center;
    justify-content: center;
    /* transform: rotate(180deg); */
`;var w=function({config:e}){var t;const n=JSON.parse(e),[l,o]=(0,i.useState)(!1),[a,s]=(0,i.useState)({Diesel:"15",Essence:"14",Aditive:"14.5",ville:0}),w=()=>i.createElement("i",{style:{fontSize:8}},"dh");function b(e=0){var t,i,l,o,r;return d(this,void 0,void 0,(function*(){const a=()=>s((e=>Object.assign(Object.assign({},e),{Diesel:"NaN",Essence:"NaN",Aditive:"NaN"})));try{let c=yield fetch(`${n.proxy}${null===(t=null==n?void 0:n.api)||void 0===t?void 0:t.base}${null===(i=null==n?void 0:n.api)||void 0===i?void 0:i.stations_path}${n.cities[e]}`,{method:"GET",redirect:"follow",headers:{"User-Agent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:100.0) Gecko/20100101 Firefox/100.0",Accept:"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8","Accept-Language":"en-US,en;q=0.5","Accept-Encoding":"gzip, deflate, br",DNT:"1",Origin:"total.smarteez.eu",Connection:"keep-alive","Upgrade-Insecure-Requests":"1","Sec-Fetch-Dest":"document","Sec-Fetch-Mode":"navigate","Sec-Fetch-Site":"none","Sec-Fetch-User":"?1"}});c||a(),c=yield c.json(),c||a(),c=yield fetch(`${n.proxy}${null===(l=null==n?void 0:n.api)||void 0===l?void 0:l.base}${null===(o=null==n?void 0:n.api)||void 0===o?void 0:o.prices_path}${null===(r=null==c?void 0:c.stations[0])||void 0===r?void 0:r.id_station}`,{method:"GET",redirect:"follow",headers:{"User-Agent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:100.0) Gecko/20100101 Firefox/100.0",Accept:"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8","Accept-Language":"en-US,en;q=0.5","Accept-Encoding":"gzip, deflate, br",DNT:"1",Origin:"total.smarteez.eu",Connection:"keep-alive","Upgrade-Insecure-Requests":"1","Sec-Fetch-Dest":"document","Sec-Fetch-Mode":"navigate","Sec-Fetch-Site":"none","Sec-Fetch-User":"?1"}}),c||a(),c=yield c.json(),c&&(null==c?void 0:c.prix)||a(),s((e=>{var t,n,i;return Object.assign(Object.assign({},e),{Diesel:null===(t=null==c?void 0:c.prix)||void 0===t?void 0:t.prix_diesel,Essence:null===(n=null==c?void 0:c.prix)||void 0===n?void 0:n.prix_essence,Aditive:null===(i=null==c?void 0:c.prix)||void 0===i?void 0:i.prix_aditive})}))}catch(e){a()}}))}const E=(0,r.useSpring)({transform:`rotateZ(${l?0:180}deg)`});return(0,i.useEffect)((()=>{b()}),[l]),i.createElement(m,null,i.createElement(v,{w:l?1:0},i.createElement(h,null,i.createElement(g,null,Object.keys(a)[0]),i.createElement(f,null),i.createElement(x,null,a.Diesel," ",i.createElement(w,null))),i.createElement(h,null,i.createElement(g,null,Object.keys(a)[1]),i.createElement(f,null),i.createElement(x,null,a.Essence,i.createElement(w,null))),i.createElement(h,null,i.createElement(g,null,Object.keys(a)[2]),i.createElement(f,null),i.createElement(x,null,a.Aditive,i.createElement(w,null))),i.createElement(u,{activationDistance:10,className:"scroll-container"},null===(t=n.cities)||void 0===t?void 0:t.map(((e,t)=>i.createElement(p,{key:t,active:Number(a.ville)===t,onClick:()=>{b(t),s((e=>Object.assign(Object.assign({},e),{ville:t})))}},e))))),i.createElement(y,{onClick:()=>o((e=>!e))},i.createElement(c,{style:E})))};const b=document.getElementById("gazprices");l.render(i.createElement(w,{config:function(){try{const e=b.getAttribute("config");return JSON.parse(e)}catch(e){return null}}()}),b)}},function(e){var t=function(t){return e(e.s=t)};e.O(0,[736],(function(){return t(253),t(656)}));e.O()}]);